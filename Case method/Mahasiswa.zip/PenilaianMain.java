import java.util.Scanner;

public class PenilaianMain {
    static Scanner input = new Scanner(System.in);

    static Mahasiswa[] mahasiswa = {
        new Mahasiswa("22001", "Ali Rahman", "Informatika"),
        new Mahasiswa("22002", "Budi Santoso", "Informatika"),
        new Mahasiswa("22003", "Citra Dewi", "Sistem Informasi Bisnis")
    };

    static MataKuliah[] mataKuliah = {
        new MataKuliah("MK001", "Struktur Data", 3),
        new MataKuliah("MK002", "Basis Data", 3),
        new MataKuliah("MK003", "Desain Web", 3)
    };

    public static void main(String[] args) {
        for (int i = 0; i < mahasiswa.length; i++) {
            mahasiswa[i].inisialisasiMataKuliah(mataKuliah.length);
            mahasiswa[i].mataKuliah = mataKuliah;

            if (mahasiswa[i].nim.equals("22001")) {
                mahasiswa[i].setNilai(0, 80, 85, 90);
                mahasiswa[i].setNilai(1, 60, 75, 70);
            } else if (mahasiswa[i].nim.equals("22002")) {
                mahasiswa[i].setNilai(0, 75, 70, 80);
            } else if (mahasiswa[i].nim.equals("22003")) {
                mahasiswa[i].setNilai(1, 85, 90, 95);
                mahasiswa[i].setNilai(2, 80, 90, 65);
            }
        }

        int pilihan = -1;
        while (pilihan != 0) {
            System.out.println("=== MENU SISTEM AKADEMIK ===");
            System.out.println("1. Tampilkan Daftar Mahasiswa");
            System.out.println("2. Tampilkan Daftar Mata Kuliah");
            System.out.println("3. Tampilkan Data Nilai Mahasiswa");
            System.out.println("4. Urutkan Mahasiswa Berdasarkan Nilai Akhir");
            System.out.println("5. Cari Mahasiswa Berdasarkan NIM");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu : ");
            pilihan = input.nextInt();

            switch (pilihan) {
                case 1:
                    tampilkanMahasiswa();
                    break;
                case 2:
                    tampilkanMataKuliah();
                    break;
                case 3:
                    tampilkanDataPenilaian();
                    break;
                case 4:
                    urutkanMahasiswa();
                    break;
                case 5:
                    cariMahasiswa();
                    break;
                case 0:
                    System.out.println("Terimakasih!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
            System.out.println();
        }
    }

    static void tampilkanMahasiswa() {
        System.out.println("Daftar Mahasiswa:");
        for (int i = 0; i < mahasiswa.length; i++) {
            System.out.println("NIM: " + mahasiswa[i].nim + " | Nama: " + mahasiswa[i].nama + " | Prodi: " + mahasiswa[i].prodi);
        }
    }

    static void tampilkanMataKuliah() {
        System.out.println("Daftar Mata Kuliah:");
        for (int i = 0; i < mataKuliah.length; i++) {
            System.out.println("Kode MK: " + mataKuliah[i].kode + " | Nama: " + mataKuliah[i].nama + " | SKS: " + mataKuliah[i].sks);
        }
    }

    static void tampilkanDataPenilaian() {
        System.out.println("Daftar Nilai Mahasiswa:");
        for (int i = 0; i < mahasiswa.length; i++) {
            for (int j = 0; j < mahasiswa[i].mataKuliah.length; j++) {
                if (mahasiswa[i].nilai[j][3] > 0) {
                    System.out.println(mahasiswa[i].nama + " | " + mahasiswa[i].mataKuliah[j].nama + " | Nilai Akhir: " + mahasiswa[i].nilai[j][3]);
                }
            }
        }
    }

    static void urutkanMahasiswa() {
        System.out.println("Data Mahasiswa Berdasarkan Nilai Akhir:");
        NilaiMahasiswa[] data = new NilaiMahasiswa[100];
        int count = 0;

        for (int i = 0; i < mahasiswa.length; i++) {
            for (int j = 0; j < mahasiswa[i].mataKuliah.length; j++) {
                double nilaiAkhir = mahasiswa[i].nilai[j][3];
                if (nilaiAkhir > 0) {
                    data[count] = new NilaiMahasiswa(mahasiswa[i].nama, mahasiswa[i].mataKuliah[j].nama, nilaiAkhir);
                    count++;
                }
            }
        }

        Penilaian.bubbleSortByNilaiAkhir(data, count);

        for (int i = 0; i < count; i++) {
            System.out.println(data[i].nama + " | " + data[i].mataKuliah + " | Nilai Akhir: " + data[i].nilaiAkhir);
        }
    }

    static void cariMahasiswa() {
        System.out.print("Masukkan NIM: ");
        String cari = input.next();
        Penilaian.bubbleSortByNIM(mahasiswa);
        int index = Penilaian.binarySearchByNIM(mahasiswa, cari);
        if (index != -1) {
            Mahasiswa m = mahasiswa[index];
            System.out.println("Ditemukan: " + m.nim + " | " + m.nama + " | " + m.prodi);
        } else {
            System.out.println("Mahasiswa tidak ditemukan.");
        }
    }
}
