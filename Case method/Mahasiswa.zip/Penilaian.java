public class Penilaian {

    // Bubble Sort berdasarkan Nilai Akhir
    public static void bubbleSortByNilaiAkhir(NilaiMahasiswa[] data, int jumlah) {
        for (int i = 0; i < jumlah - 1; i++) {
            for (int j = 0; j < jumlah - i - 1; j++) {
                if (data[j].nilaiAkhir < data[j + 1].nilaiAkhir) {
                    NilaiMahasiswa temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    // Bubble Sort berdasarkan NIM
    public static void bubbleSortByNIM(Mahasiswa[] data) {
        for (int i = 0; i < data.length - 1; i++) {
            for (int j = 0; j < data.length - i - 1; j++) {
                if (data[j].nim.compareTo(data[j + 1].nim) > 0) {
                    Mahasiswa temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    // Binary Search berdasarkan NIM
    public static int binarySearchByNIM(Mahasiswa[] data, String nimCari) {
        int kiri = 0, kanan = data.length - 1;
        while (kiri <= kanan) {
            int tengah = (kiri + kanan) / 2;
            int banding = data[tengah].nim.compareTo(nimCari);
            if (banding == 0) {
                return tengah;
            } else if (banding < 0) {
                kiri = tengah + 1;
            } else {
                kanan = tengah - 1;
            }
        }
        return -1;
    }
}
