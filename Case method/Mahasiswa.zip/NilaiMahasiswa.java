public class NilaiMahasiswa {
    String nama;
    String mataKuliah;
    double nilaiAkhir;

    public NilaiMahasiswa(String nama, String mataKuliah, double nilaiAkhir) {
        this.nama = nama;
        this.mataKuliah = mataKuliah;
        this.nilaiAkhir = nilaiAkhir;
    }
}
